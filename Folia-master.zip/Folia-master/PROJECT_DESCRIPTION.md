# Project overview

This page has been moved to [the PaperMC documentation](https://docs.papermc.io/folia/reference/overview) site.
