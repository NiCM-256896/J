# Region Logic

This page has been moved to [the PaperMC documentation](https://docs.papermc.io/folia/reference/region-logic) site.
